# Accessing Admin Mode

Admin mode is available exclusively to users who have been granted administrative privileges. The only user granted with this capability is listed below:

- Username: admin
- Password: admin

To use the admin features, such as creating, editing, and deleting books from the website, please log in using these credentials.

# Regular User mode

You can create a regular account in the registration form or you can take a look at the list of users in the "users.json" file and use any of the written credentials.
