# php-5-registration

- [ ] a.
- [ ] b.
- [ ] c.
- [ ] d.
- [ ] e.
- [ ] f.
- [ ] g.
- [ ] h.
- [ ] i.
