const people = [
    {
        name: "Luna",
        photo: "luna.jpg",
        paid: 0,
        to_pay: 120000
    },
    {
        name: "Flora",
        photo: "floh.jpg",
        paid: 0,
        to_pay: 95000
    },
    {
        name: "Seraphine",
        photo: "sera.jpg",
        paid: 0,
        to_pay: 300500
    },
        {
        name: "Zephyr",
        photo: "zeph.jpg",
        paid: 0,
        to_pay: 32000
    },
    {
        name: "Ruby",
        photo: "ruby.jpg",
        paid: 0,
        to_pay: 55000
    }
];
